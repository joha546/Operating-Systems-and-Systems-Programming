Download this folder. It should download as a zip.

To copy onto inst servers, check out the scp tutorial from lab.

Then, once you have a <filename>.zip file on your inst account:
unzip <filename>.zip

(replacing <filename>.zip with the name of your filename)
